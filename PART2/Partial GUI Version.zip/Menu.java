import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.*;
import javafx.event.*;

import java.io.File;
import java.io.IOException;

public class Menu {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    Text errorText;
    @FXML
    TextField filenameInput;

    public void newGame(ActionEvent e) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("game.fxml"));
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void loadGame(ActionEvent e) throws Exception {
        root = FXMLLoader.load(getClass().getResource("load.fxml"));
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();

        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void exit(ActionEvent e) {
        System.exit(0);
    }

    public void submit(ActionEvent e) throws IOException {
        String filename = filenameInput.getText();
        File saveFile = new File(filename + ".txt");

        if (!saveFile.createNewFile()) { // file exists

        }
        else {
            errorText.setText("Error: File does not exist.");
        }
    }  

    public void backToMenu(ActionEvent e) throws Exception {
        root = FXMLLoader.load(getClass().getResource("menu.fxml"));
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();

        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}