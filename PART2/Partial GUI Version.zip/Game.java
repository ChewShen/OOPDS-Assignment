import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import javax.lang.model.util.ElementScanner14;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.*;

public class Game {
    private Stage stage;
    private Scene scene;
    private Parent root;
    private AnchorPane scenePane;

    @FXML
    Text notificationText;
    @FXML
    TextField enterCommand;
    @FXML
    Button submitCommand;

    public static void main() {
        Scanner input = new Scanner(System.in);
        Random random = new Random();

        ArrayList<Card> deck = new ArrayList<>();

        // 4 suits - clubs, spades, diamonds, hearts
        String[] cardSuit = {"c","s","d","h"};
        // 13 cards per suit = 52 cards in a deck
        String[] cardRank = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
        
        ArrayList<Card> center = new ArrayList<>();

        //creates 4 players and gives them each an empty hand and score of 0
        ArrayList<Player> players = new ArrayList<Player>();
        int numOfPlayers = 4;
        for (int i = 0; i < numOfPlayers; i++)
            players.add(new Player(new HashSet<Card>(), 0));

        boolean newGame = false;
        boolean roundEnd = false;

        System.out.println("\nBefore Start, Please be aware of how to play the game.");
        System.out.println("Heres are the rules and commands.");
        promptEnterKey();
        rule();
        System.out.print("\n");
        Guide();

        while (!newGame) {
        roundEnd = false;

        // adds 52 cards to the deck
        deck.clear();
        for (int i = 0; i < cardSuit.length; i++) {
            for (int j = 0; j < cardRank.length; j++) {
                deck.add(new Card(cardSuit[i], cardRank[j]));
            }
        }
        //shuffles the deck so the 52 cards are randomized
        Collections.shuffle(deck);
        
        //adds the first card in the deck to the center and removes it from the deck
        center.clear();
        center.add(deck.get(0));
        deck.remove(0);

        int previousTurn = 0;
        //turn + 1 = which player's turn it is
        int turn = 0;

        switch (center.get(0).getRank()) {
        case "A":
        case "5":
        case "9":
        case "K":
            turn = 0;
            break;

        case "2":
        case "6":
        case "10":
            turn = 1;
            break;

        case "3":
        case "7":
        case "J":
            turn = 2;
            break;

        case "4":
        case "8":
        case "Q":
            turn = 3;
            break;
        }


        //randomly distributes 7 cards to each player
        for (int i = 0; i < numOfPlayers; i++) {
            players.get(i).hand.clear();
            for (int j = 0; j < 7; j++) {
                int randomIndex = random.nextInt(deck.size());
                players.get(i).addCardToHand(deck.get(randomIndex));
                deck.remove(randomIndex);
            }
        }

        //records the cards played to see who played the highest value
        ArrayList< Map<Card, Player> > sameSuit = new ArrayList<>();
        int errors = 0;
        int trickNum = 1;
        //each trick begins here
        while (!roundEnd) {
        int numOfPlays = 0;

        while (numOfPlays < 4) {
            //displays trick number
            System.out.println("\nTrick #" + trickNum);

            //displays each player's deck
            for (int i = 0; i < numOfPlayers; i++)
                System.out.println("Player" + (i + 1) + ": " + players.get(i).getHand());
            
            //displays the center deck
            System.out.println("Center : " + center);
            //displays the main deck
            System.out.println("Deck   : " + deck);

            //displays score for each player
            System.out.print("Score: ");
            for (int i = 0; i < numOfPlayers; i++)
                System.out.print("Player" + (i + 1) + ": " + players.get(i).getScore() + " | ");
            System.out.print("\n");

            //displays which player's turn it is
            System.out.print("Turn : Player" + (turn + 1) + "\n");

            System.out.print("> ");

            String command = input.nextLine();
            command = command.toLowerCase(); //

            switch (command) {
            // start a new game
            case "s":
                newGame = true;
                break;

            //exit the game
            case "x":
                System.exit(0);
                break;

            //draw cards into player's deck until playable card obtained
            case "d":
                boolean validCard = false;

                while (!validCard) {
                    //checks if there are any cards in deck
                    if (deck.size() > 0) {
                        int randomIndex = random.nextInt(deck.size());
                        players.get(turn).addCardToHand(deck.get(randomIndex));
                        System.out.println("Drew card " + deck.get(randomIndex) + ".");

                        if (deck.get(randomIndex).getRank().equals(center.get(0).getRank())
                        || deck.get(randomIndex).getSuit().equals(center.get(0).getSuit())) {
                            validCard = true;
                        }
                        deck.remove(randomIndex);
                    }
                    //if no cards, skips player's turn
                    else {
                        System.out.println("No cards available to be drawn.");
                        System.out.println("Player" + (players.indexOf(players.get(turn)) + 1) + "\'s turn will be skipped.");
                        
                        numOfPlays += 1;
                        switch(turn) {
                            case 0:
                                turn = 1;
                                break;
                            case 1:
                                turn = 2;
                                break;
                            case 2:
                                turn = 3;
                                break;
                            case 3:
                                turn = 0;
                                break;
                            }

                        break;
                    }
                }

                break;

            case "":
                System.out.println("Not a valid input.");
                break;

            default:
            
            //depending on which player's turn it is, moves card to the center
            Card cardToMove;
            Map<Card, Player> cardPlayed = new HashMap<>();
            boolean cardMatchCenter = false;
            boolean cardInHand = false;
            while (!cardMatchCenter && !cardInHand) {
                String chosenCard = command;
                String chosenCardSuit = Character.toString(chosenCard.charAt(0));
                chosenCardSuit = chosenCardSuit.toLowerCase();
                //substring instead of charAt because card rank may be equal to 10
                String chosenCardRank = chosenCard.substring(1);
                chosenCardRank = chosenCardRank.toUpperCase();

                cardToMove = new Card(chosenCardSuit, chosenCardRank);
            
                //checks if the card exist in player's hand
                //if yes, moves the card to center deck
                //if no, throws exception
                //limit of for loop = number of cards in player's hand
                for (Card card : players.get(turn).hand) {
                    if (card.isEqual(cardToMove)) {
                        cardInHand = true;

                        if (center.size() == 0) {
                            center.add(cardToMove);
                            players.get(turn).removeCardFromHand(card);
                            
                            cardPlayed.clear();
                            cardPlayed.put(cardToMove, players.get(turn));
                            sameSuit.add(cardPlayed);

                            cardMatchCenter = true;
                            numOfPlays += 1;
                            break;
                        }

                        cardToMove = card;
                        break;
                    }
                    else {
                        cardInHand = false;
                    }
                }
                if (!cardInHand) {
                    System.out.println("Card does not exist in the player's deck.");
                    break;
                }
                
                //checks if the card matches the rank/suit of the lead card
                //only makes the check if there is at least 1 card in center
                //if yes, allows the move
                //if no, throws exception
                if (!cardMatchCenter) {
                    if (cardToMove.getSuit().equals(center.get(0).getSuit())) {
                        cardMatchCenter = true;
                        players.get(turn).removeCardFromHand(cardToMove);
                        center.add(cardToMove);
                        
                        cardPlayed.clear();
                        cardPlayed.put(cardToMove, players.get(turn));
                        sameSuit.add(cardPlayed);

                        numOfPlays += 1;
                    }

                    else if (cardToMove.getRank().equals(center.get(0).getRank())) {
                        cardMatchCenter = true;
                        players.get(turn).removeCardFromHand(cardToMove);
                        center.add(cardToMove);
                        
                        cardPlayed.clear();
                        cardPlayed.put(cardToMove, players.get(turn));
                        
                        numOfPlays += 1;
                    }

                    else {
                        System.out.println("Card does not have a matching rank/suit.");
                        cardMatchCenter = false;
                        break;
                    }
                }// end of moving card
            }

            previousTurn = turn;
            
            if (cardMatchCenter && cardInHand) {
                switch(turn) {
                    case 0:
                        turn = 1;
                        break;
                    case 1:
                        turn = 2;
                        break;
                    case 2:
                        turn = 3;
                        break;
                    case 3:
                        turn = 0;
                        break;
                    }
            }

            } // end of command switch

            if (players.get(previousTurn).hand.isEmpty()) {
                System.out.println("* * * Player" + (players.indexOf(players.get(previousTurn)) + 1) + " wins the round * * *");
                roundEnd = true;
                break;
            }

            if (newGame == true)
                break;

        } // end of player's turn

        if (newGame == true)
            break;

        //checks the cardsToCompare to see who played the card with the highest rank
        //has to be card with same suit as lead card
        //if 2 have same rank, player who came first wins

        Card highestRank = new Card();
        int winnerIndex = 0;

        //temporarily assigns highest ranked card to
        //the first entry in sameSuit
        for (var entry: sameSuit.get(0).entrySet())
            highestRank = entry.getKey();

        //compares all other entries in sameSuit to find highest valued card
        for (int i = 1; i < sameSuit.size(); i++) {
            for (var entry: sameSuit.get(i).entrySet())
                if (entry.getKey().getValue() > highestRank.getValue()) {
                    highestRank = entry.getKey();
                    winnerIndex = i;
                }
        }

        if (!roundEnd)
            System.out.println("* * * Player" + (players.indexOf(sameSuit.get(winnerIndex).get(highestRank)) + 1) + " wins Trick #" + trickNum + " * * *");

        //assigns turn to winning player
        turn = players.indexOf(sameSuit.get(winnerIndex).get(highestRank));
        trickNum += 1;

        //clears the sameSuit and center decks to start a new trick
        sameSuit.clear();
        center.clear();
        } // end of trick

        int totalScore = 0;
        //records each player's score at the end of a round
        if (roundEnd == true) {
            for (int i = 0; i < numOfPlayers; i++) {
                totalScore = 0;
                for (Card card : players.get(i).hand) {
                    totalScore += card.getValue();
                }
                players.get(i).setScore(totalScore);
            }
        }

        newGame = false;
        } // end of round
    }

    public static void promptEnterKey(){
        System.out.print("\n");
        System.out.println("Press \"ENTER\" to continue...");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();

    }

    public static void Guide(){
        System.out.println("+----------------------------------------------------------------------------------+");
        System.out.println("|                                   Command Guidebook                              |");
        System.out.println("+---+------------------------------------------------------------------------------+");
        System.out.println("| s | To reset the current game. (No progress will be saved)                       |");
        System.out.println("| r | To load the game from your save file.                                        |");
        System.out.println("| x | To save and exit the game.                                                   |");
        System.out.println("| d | To draw a card until you obtain specific condition same as the center card.  |");
        System.out.println("| h | To View the Command Guide.                                                   |");
        System.out.println("| g | To view the game rule.                                                       |");
        System.out.println("+---+------------------------------------------------------------------------------+");
        promptEnterKey();
    }
    
    public static void rule(){
        System.out.print("\n");
        System.out.println("+----------------------------------------------------------------------------------+");
        System.out.println("|                                     Objective                                    |");
        System.out.println("+----------------------------------------------------------------------------------+");
        System.out.println("| Be the first player to get rid of your hand.                                     |");
        System.out.println("+----------------------------------------------------------------------------------+");
        System.out.print("\n\n");
        System.out.println("+--------------------------------------------------------------------------------------+");
        System.out.println("|                                         Rule                                         |");
        System.out.println("+--------------------------------------------------------------------------------------+");
        System.out.println("| The goal is to be the first player to get rid of the cards in your hand.             |");
        System.out.println("|                                                                                      |");
        System.out.println("| The relative player deals a card with same ranking or Suit as the FIRST center       |"); 
        System.out.println("| card from their hand. If a player cannot lay down a card, they must draw a card from |");
        System.out.println("| the draw pile. If they still cannot play, they continue drawing until they draw a    |");
        System.out.println("| playerable card.                                                                     |");
        System.out.println("|                                                                                      |");
        System.out.println("| After everyone has played one card, the player who played the highest card of the    |"); 
        System.out.println("| initial suit wins \"the trick\".                                                       |");
        System.out.println("| The winner of a trick leads the next card for the next round.                        |");
        System.out.println("|                                                                                      |");
        System.out.println("| Continue in this manner until one player has emptied their hand. The first player to |");
        System.out.println("| do so is the winner.                                                                 |");
        System.out.println("|                                                                                      |");
        System.out.println("| Final score will be calculated after one player has emptied their hand, the player   |");
        System.out.println("| with the lowest score is the winner.                                                 |");
        System.out.println("+--------------------------------------------------------------------------------------+");
    }

    public void draw() {

    }

    public void save(ActionEvent e) throws Exception {
        notificationText.setText("Please enter the filename to save to:");

        submitCommand.setOnMouseClicked(new EventHandler<MouseEvent>() {
 
            @Override 
            public void handle(MouseEvent t) { 
                try {
                    while (true) {
                        String filename = enterCommand.getText();

                        File saveFile = new File(filename + ".txt");

                        if (saveFile.createNewFile())
                            notificationText.setText("File created: " + saveFile.getName());
                        else {
                            notificationText.setText("File already exists.");
                            break;
                        }

                        FileWriter writer = new FileWriter(saveFile.getName());

                        break;
                    }
                }
                catch (IOException exception) {}
            }
        });

        // //save data into the file
        // try {
        //     //open the file in FileWriter
        //     FileWriter myWriter = new FileWriter(filename+".txt");  
        //     myWriter.write(trickNum + "\n");                        //save trick number
        //     for (int i = 0; i < numOfPlayers; i++)   
        //         myWriter.write(players.get(i).getHand()+"\n");      //save player handcards
        //     myWriter.write(center + "\n");                          //save center card
        //     myWriter.write(deck + "\n");                            //save deck
        //     for (int i = 0; i < numOfPlayers; i++)
        //         myWriter.write(players.get(i).getScore() + "\n");   //save players' scores
        //     myWriter.write(turn);                                   //save turn
        //     //close the file
        //     myWriter.close();   
        //     System.out.println("Successfully wrote to the file.");
        //     System.exit(0);
        //     } 
        // catch (IOException e) {
        //     System.out.println("An error occurred.");
        //     e.printStackTrace();
        // }
    }

    public void submit(ActionEvent e) throws IOException {
        String command = enterCommand.getText();

        switch (command) {
        case "":
            notificationText.setText("Not a valid input.");
            break;

        case "s":
            
        case "x":
            notificationText.setText("Would you like to save? (y/n)");

            submitCommand.setOnMouseClicked(new EventHandler<MouseEvent>() {
 
            @Override 
            public void handle(MouseEvent t) { 
                try {
                    if (enterCommand.getText() == "y") {
                        String filename = enterCommand.getText();

                        File saveFile = new File(filename + ".txt");

                        if (saveFile.createNewFile())
                            notificationText.setText("File created: " + saveFile.getName());
                        else {
                            notificationText.setText("File already exists.");
                            break;
                        }

                        FileWriter writer = new FileWriter(saveFile.getName());

                        break;
                    }
                }
                catch (IOException exception) {}
            }
        });

        case "d":

            
        default:
        
        
        }

        // while (true) {
        //     String filename = enterCommand.getText();

        //     File saveFile = new File(filename + ".txt");

        //     if (saveFile.createNewFile())
        //         notificationText.setText("File created: " + saveFile.getName());
        //     else {
        //         notificationText.setText("File already exists.");
        //         break;
        //     }

        //     FileWriter writer = new FileWriter(saveFile.getName());

        //     break;
        // }
    }

    public void menu(ActionEvent e) throws IOException {
        root = FXMLLoader.load(getClass().getResource("menu.fxml"));
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();

        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}